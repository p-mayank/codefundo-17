from django.apps import AppConfig


class CaptionDownloaderConfig(AppConfig):
    name = 'caption_downloader'
